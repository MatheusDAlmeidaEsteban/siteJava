package com.example.SiteJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiteJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
