package com.example.SiteJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiteJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiteJavaApplication.class, args);
	}

}
